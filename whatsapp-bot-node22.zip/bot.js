
const { makeWASocket, useSingleFileAuthState } = require('@whiskeysockets/baileys')
const figlet = require('figlet')
const chalk = require('chalk')
const moment = require('moment-timezone')
const { Boom } = require('@hapi/boom')
const fs = require('fs')

console.log(chalk.green(figlet.textSync("WhatsApp Bot")))

const { state, saveState } = useSingleFileAuthState('./auth.json')

async function startBot() {
    const sock = makeWASocket({
        auth: state,
        printQRInTerminal: true,
    })

    sock.ev.on('creds.update', saveState)

    sock.ev.on('messages.upsert', async (m) => {
        const msg = m.messages[0]
        if (!msg.message || msg.key.fromMe) return

        const from = msg.key.remoteJid
        const message = msg.message.conversation || msg.message.extendedTextMessage?.text || ""

        if (message === '.ping') {
            await sock.sendMessage(from, { text: '🏓 Pong!' })
        } else if (message === '.menu') {
            await sock.sendMessage(from, { text: '📜 Menu:\n1. .ping\n2. .menu\n3. .vv (view once)' })
        } else if (message.startsWith('.vv')) {
            if (msg.message.imageMessage) {
                const mediaBuffer = await sock.downloadMediaMessage(msg)
                await sock.sendMessage(from, { image: mediaBuffer, caption: '🖼️ View Once Bypass' })
            } else {
                await sock.sendMessage(from, { text: '⚠️ No image detected.' })
            }
        }
    })
}

startBot()
